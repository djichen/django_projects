from django.apps import AppConfig


class BoatsConfig(AppConfig):
    name = 'boats'
